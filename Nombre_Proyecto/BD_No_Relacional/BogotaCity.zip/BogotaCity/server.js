/**
 * Bogotá City FC - Sistema de Gestión de Jugadores
 * 
 * Este servidor Node.js con Express gestiona la información de jugadores, eventos,
 * categorías y rendimiento de jugadores para el club Bogotá City FC.
 * Incluye autenticación, autorización por roles y un sistema de papelera/historial.
 */

// Importación de módulos requeridos
const express = require('express'); // Framework web
const path = require('path'); // Utilidades para manejo de rutas de archivos
const { MongoClient, ObjectId } = require('mongodb'); // Cliente MongoDB
const cors = require('cors'); // Middleware para CORS
const session = require('express-session'); // Manejo de sesiones
const PDFDocument = require('pdfkit');
const blobStream = require('blob-stream');

// Inicialización de la aplicación Express
const app = express();
const port = 3000; // Puerto donde correrá el servidor

// ========== CONFIGURACIÓN DE MIDDLEWARES ==========

// Middleware para parsear JSON en las solicitudes
app.use(express.json());

// Configuración de CORS (Cross-Origin Resource Sharing)
app.use(cors({
  origin: 'http://localhost:' + port, // Origen permitido
  credentials: true, // Permite enviar credenciales (cookies)
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'] // Métodos HTTP permitidos
}));

// Configuración de sesiones
app.use(session({
  secret: 'secreto_seguro_bogotacity', // Clave secreta para firmar la cookie
  resave: false, // No volver a guardar la sesión si no cambia
  saveUninitialized: false, // No guardar sesiones vacías
  cookie: { 
    secure: false, // En producción debería ser true (HTTPS)
    httpOnly: true, // La cookie no es accesible desde JS
    sameSite: 'lax' // Protección contra CSRF
  }
}));

// Servir archivos estáticos desde la carpeta 'public'
app.use(express.static(path.join(__dirname, 'public')));

// ========== CONFIGURACIÓN DE BASE DE DATOS ==========

// URL de conexión a MongoDB
const mongoUrl = 'mongodb://localhost:27017';
const dbName = 'BogotaCityFC'; // Nombre de la base de datos

// Variables para almacenar la conexión y colecciones
let db;
let collections = {};
let dbReady = false; // Bandera para saber si la DB está lista

/**
 * Función para conectar a MongoDB y configurar las colecciones
 */
async function connectDB() {
  try {
    const client = new MongoClient(mongoUrl, { 
      useUnifiedTopology: true,
      useNewUrlParser: true
    });
    await client.connect();
    console.log('✅ Conectado a MongoDB');
    
    // Obtener referencia a la base de datos
    db = client.db(dbName);
    
    // Configurar referencias a las colecciones
    collections = {
      usuario: db.collection('usuario'),
      categoria: db.collection('categoria'),
      evento: db.collection('evento'),
      rendimientoJugador: db.collection('rendimientoJugador'),
      papelera: db.collection('papelera') // Colección para el historial de cambios
    };
    
    dbReady = true; // Marcar la DB como lista
    
    // Crear índices para mejorar el rendimiento de búsquedas
    await collections.usuario.createIndex({ idUsuario: 1 }, { unique: true });
    await collections.papelera.createIndex({ fecha: -1 }); // Índice para ordenar por fecha descendente
    console.log('Índices creados');
  } catch (err) {
    console.error('❌ Error al conectar a MongoDB:', err);
    process.exit(1); // Terminar la aplicación si no se puede conectar a la DB
  }
}

// Middleware para verificar conexión a la base de datos
app.use((req, res, next) => {
  if (!dbReady) return res.status(503).json({ error: 'DB no disponible' });
  next();
});

// ========== MIDDLEWARES DE AUTENTICACIÓN Y AUTORIZACIÓN ==========

/**
 * Middleware para requerir un rol específico
 * @param {string} role - Rol requerido para acceder a la ruta
 */
function requireRole(role) {
  return (req, res, next) => {
    if (!req.session.user) {
      return res.status(401).json({ error: 'No autenticado' });
    }
    if (req.session.user.role !== role) {
      return res.status(403).json({ error: 'Acceso denegado' });
    }
    next();
  };
}

// ========== FUNCIONES PARA GENERAR PDF ==========

/**
 * Genera un PDF con los datos de una colección
 * @param {Array} data - Datos a incluir en el PDF
 * @param {string} title - Título del documento
 * @returns {Promise<Buffer>} - Buffer del PDF generado
 */
async function generatePDF(data, title) {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument();
      const stream = doc.pipe(blobStream());

      // Configuración del documento
      doc.fontSize(20).text(title, { align: 'center' });
      doc.moveDown();

      // Agregar fecha de generación
      doc.fontSize(10).text(`Generado el: ${new Date().toLocaleString()}`, { align: 'right' });
      doc.moveDown();

      // Configurar tabla
      const headers = Object.keys(data[0]);
      const rows = data.map(item => Object.values(item));

      // Ajustar el ancho de las columnas
      const columnWidth = doc.page.width / headers.length;

      // Encabezados de la tabla
      doc.font('Helvetica-Bold');
      headers.forEach((header, i) => {
        doc.text(header, i * columnWidth, doc.y, { width: columnWidth });
      });
      doc.moveDown();

      // Filas de datos
      doc.font('Helvetica');
      rows.forEach(row => {
        row.forEach((cell, i) => {
          // Convertir objetos a string para mostrarlos
          const cellText = typeof cell === 'object' ? JSON.stringify(cell) : String(cell);
          doc.text(cellText, i * columnWidth, doc.y, { width: columnWidth });
        });
        doc.moveDown();
      });

      doc.end();

      stream.on('finish', () => {
        resolve(stream.toBlob('application/pdf'));
      });

      stream.on('error', reject);
    } catch (err) {
      reject(err);
    }
  });
}

// ========== RUTAS PARA DESCARGAR PDF ==========

// Ruta para descargar PDF de cualquier colección (solo admin)
app.get('/download-pdf/:collection', requireRole('admin'), async (req, res) => {
  try {
    const { collection } = req.params;
    const validCollections = ['usuario', 'categoria', 'evento', 'rendimientoJugador'];

    if (!validCollections.includes(collection)) {
      return res.status(400).json({ error: 'Colección no válida' });
    }

    // Obtener datos de la colección
    const data = await collections[collection].find({}).toArray();
    
    if (data.length === 0) {
      return res.status(404).json({ error: 'No hay datos para generar el PDF' });
    }

    // Generar el PDF
    const title = `Reporte de ${collection} - Bogotá City FC`;
    const pdfBuffer = await generatePDF(data, title);

    // Configurar headers para la descarga
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=${collection}_report.pdf`);

    // Enviar el PDF
    res.send(pdfBuffer);
  } catch (err) {
    console.error('❌ Error al generar PDF:', err);
    res.status(500).json({ error: 'Error al generar PDF', details: err.message });
  }
});

// Ruta para descargar PDF de jugadores por evento (solo admin)
app.get('/download-jugadores-pdf/:idEvento', requireRole('admin'), async (req, res) => {
  try {
    const idEvento = parseInt(req.params.idEvento);

    if (isNaN(idEvento)) {
      return res.status(400).json({ error: 'ID de evento inválido' });
    }

    // Obtener datos de jugadores por evento
    const jugadores = await collections.rendimientoJugador.aggregate([
      { $match: { idEventoFK: idEvento } },
      {
        $lookup: {
          from: 'usuario',
          localField: 'idUsuarioFK',
          foreignField: 'idUsuario',
          as: 'jugador'
        }
      },
      { $unwind: '$jugador' },
      {
        $project: {
          _id: 0,
          idEventoFK: 1,
          asistencia: 1,
          metrosRecorridos: 1,
          pasesRealizados: 1,
          golesRealizados: 1,
          pasesFallidos: 1,
          golesFallidos: 1,
          comentarios: 1,
          'jugador.nombreUsuario': 1,
          'jugador.idUsuario': 1
        }
      }
    ]).toArray();

    if (jugadores.length === 0) {
      return res.status(404).json({ 
        error: 'No hay jugadores para este evento',
        idEvento: idEvento
      });
    }

    // Aplanar la estructura para la tabla PDF
    const flattenedData = jugadores.map(j => ({
      idJugador: j.jugador.idUsuario,
      nombre: j.jugador.nombreUsuario,
      asistencia: j.asistencia ? 'Sí' : 'No',
      metrosRecorridos: j.metrosRecorridos,
      pasesRealizados: j.pasesRealizados,
      golesRealizados: j.golesRealizados,
      pasesFallidos: j.pasesFallidos,
      golesFallidos: j.golesFallidos,
      comentarios: j.comentarios || 'N/A'
    }));

    // Generar el PDF
    const title = `Reporte de Jugadores - Evento ${idEvento}`;
    const pdfBuffer = await generatePDF(flattenedData, title);

    // Configurar headers para la descarga
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=jugadores_evento_${idEvento}.pdf`);

    // Enviar el PDF
    res.send(pdfBuffer);
  } catch (err) {
    console.error('❌ Error al generar PDF de jugadores:', err);
    res.status(500).json({ error: 'Error al generar PDF', details: err.message });
  }
});
// ========== FUNCIONES PARA EL HISTORIAL/PAPELERA ==========

/**
 * Registra una operación de inserción en la papelera/historial
 * @param {string} collection - Nombre de la colección afectada
 * @param {object} documento - Documento insertado
 * @param {object} usuario - Información del usuario que realizó la operación
 */
async function registrarInsercion(collection, documento, usuario) {
  try {
    await collections.papelera.insertOne({
      tipo: 'insercion',
      coleccion: collection,
      datos: documento,
      fecha: new Date(),
      usuario: {
        id: usuario.id,
        nombre: usuario.nombreUsuario,
        idUsuario: usuario.idUsuario
      }
    });
  } catch (err) {
    console.error('Error registrando inserción:', err);
  }
}

/**
 * Registra una operación de eliminación en la papelera/historial
 * @param {string} collection - Nombre de la colección afectada
 * @param {string} id - ID del documento eliminado
 * @param {object} usuario - Información del usuario que realizó la operación
 */
async function registrarEliminacion(collection, id, usuario) {
  try {
    // Buscar el documento antes de eliminarlo para guardarlo en el historial
    const documento = await collections[collection].findOne({ _id: new ObjectId(id) });
    if (documento) {
      await collections.papelera.insertOne({
        tipo: 'eliminacion',
        coleccion: collection,
        datos: documento,
        fecha: new Date(),
        usuario: {
          id: usuario.id,
          nombre: usuario.nombreUsuario,
          idUsuario: usuario.idUsuario
        },
        estado: 'eliminado'
      });
    }
  } catch (err) {
    console.error('Error registrando eliminación:', err);
  }
}

// Middleware para registrar automáticamente operaciones POST exitosas
app.use(async (req, res, next) => {
  if (req.method === 'POST' && req.session.user) {
    const originalSend = res.send;
    res.send = async function (body) {
      if (res.statusCode === 201) { // Solo registrar inserciones exitosas (código 201)
        const urlParts = req.originalUrl.split('/');
        const collection = urlParts[urlParts.length - 1];
        if (collections[collection]) {
          try {
            // Parsear el cuerpo de la respuesta para obtener los datos insertados
            const responseBody = typeof body === 'string' ? JSON.parse(body) : body;
            await registrarInsercion(collection, responseBody.usuario || responseBody, req.session.user);
          } catch (err) {
            console.error('Error procesando body para registro:', err);
          }
        }
      }
      originalSend.apply(res, arguments);
    };
  }
  next();
});

// ========== RUTAS DE AUTENTICACIÓN ==========

// Ruta para iniciar sesión
app.post('/login', async (req, res) => {
  try {
    const { documento, contrasenia } = req.body;

    // Validar que se enviaron credenciales
    if (!documento || !contrasenia) {
      return res.status(400).json({ error: 'Documento y contraseña requeridos' });
    }

    // Buscar usuario en la base de datos
    const usuario = await collections.usuario.findOne({
      idUsuario: parseInt(documento),
      contrasenia
    });

    if (!usuario) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    // Guardar información del usuario en la sesión
    req.session.user = {
      id: usuario._id,
      idUsuario: usuario.idUsuario,
      nombreUsuario: usuario.nombreUsuario,
      role: usuario.tipoUsuario === 'admin' ? 'admin' : 'jugador'
    };

    res.json({ success: true, user: req.session.user });
  } catch (err) {
    console.error('❌ Error en login:', err);
    res.status(500).json({ error: 'Error en el servidor' });
  }
});

// Ruta para cerrar sesión
app.post('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      console.error('Error al cerrar sesión:', err);
      return res.status(500).json({ error: 'Error al cerrar sesión' });
    }
    res.json({ success: true });
  });
});

// Ruta para obtener el usuario actualmente autenticado
app.get('/current-user', (req, res) => {
  if (!req.session.user) return res.status(401).json({ error: 'No autenticado' });
  res.json({ user: req.session.user });
});

// Ruta alternativa para obtener datos de sesión
app.get('/session-data', (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ error: 'No autenticado' });
  }
  res.json(req.session.user);
});

// ========== RUTAS PROTEGIDAS (requieren autenticación y rol específico) ==========

// Ruta para crear un nuevo usuario (solo admin)
app.post('/usuario', requireRole('admin'), async (req, res) => {
  try {
    const { nombreUsuario, idUsuario, contrasenia, tipoUsuario, telefonoUsuario, estadoUsuario } = req.body;

    // Validar campos obligatorios
    if (!nombreUsuario || !idUsuario || !contrasenia || !tipoUsuario || !telefonoUsuario) {
      return res.status(400).json({ error: 'Todos los campos son obligatorios' });
    }

    // Verificar si el ID de usuario ya existe
    const usuarioExistente = await collections.usuario.findOne({ idUsuario: parseInt(idUsuario) });
    if (usuarioExistente) {
      return res.status(400).json({ error: 'El ID ya existe' });
    }

    // Crear objeto con los datos del nuevo usuario
    const nuevoUsuario = {
      nombreUsuario,
      idUsuario: parseInt(idUsuario),
      contrasenia,
      tipoUsuario,
      telefonoUsuario,
      estadoUsuario: estadoUsuario === "1" || estadoUsuario === true,
      role: tipoUsuario === 'admin' ? 'admin' : 'jugador'
    };

    // Insertar el nuevo usuario en la base de datos
    const result = await collections.usuario.insertOne(nuevoUsuario);
    
    res.status(201).json({ 
      success: true, 
      usuario: nuevoUsuario,
      insertedId: result.insertedId
    });
  } catch (err) {
    console.error('❌ Error al crear usuario:', err);
    res.status(500).json({ error: 'Error al crear usuario', details: err.message });
  }
});

app.post('/evento', requireRole('admin'), async (req, res) => {
  try {
    const { nombreEvento, fechaEvento, descripcionEvento, categoria } = req.body;

    // Validar campos obligatorios
    if (!nombreEvento || !fechaEvento || !categoria) {
      return res.status(400).json({ error: 'Los campos nombreEvento, fechaEvento y categoria son obligatorios' });
    }

    // Crear el objeto del evento
    const nuevoEvento = {
      nombreEvento,
      fechaEvento: new Date(fechaEvento), // Convierte a objeto Date
      descripcionEvento: descripcionEvento || '',
      categoria
    };

    // Insertar en la colección
    const result = await collections.evento.insertOne(nuevoEvento);

    res.status(201).json({ 
      success: true, 
      evento: nuevoEvento,
      insertedId: result.insertedId
    });
  } catch (err) {
    console.error('❌ Error al crear evento:', err);
    res.status(500).json({ error: 'Error al crear evento', details: err.message });
  }
});

// Ruta para eliminar o modificar registros (solo admin)
app.delete('/:collection/:id', requireRole('admin'), async (req, res) => {
  try {
    const { collection, id } = req.params;
    const { action, updatedData } = req.body; // Nuevos parámetros

    if (!['usuario', 'categoria', 'evento', 'rendimientoJugador'].includes(collection)) {
      return res.status(400).json({ error: 'Colección no válida' });
    }

    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: 'ID no válido' });
    }

    const objectId = new ObjectId(id);

    if (action === 'modify' && updatedData) {
      // Lógica para modificar
      const result = await collections[collection].updateOne(
        { _id: objectId },
        { $set: updatedData }
      );

      if (result.modifiedCount === 0) {
        return res.status(404).json({ error: 'Registro no encontrado o sin cambios' });
      }

      return res.json({ 
        success: true, 
        action: 'modified',
        modifiedId: id
      });
    } else if (action === 'delete') {
      // Lógica original para eliminar
      await registrarEliminacion(collection, id, req.session.user);
      const result = await collections[collection].deleteOne({ _id: objectId });

      if (result.deletedCount === 0) {
        return res.status(404).json({ error: 'Registro no encontrado' });
      }

      return res.json({ 
        success: true, 
        action: 'deleted',
        deletedId: id
      });
    } else {
      return res.status(400).json({ error: 'Acción no válida' });
    }
  } catch (err) {
    console.error(`Error en ${req.params.collection}:`, err);
    res.status(500).json({ error: 'Error en el servidor' });
  }
});

// Ruta para la página de gráficas (solo admin)
app.get('/graficas', requireRole('admin'), (req, res) => {
  res.sendFile(path.join(__dirname, 'templates', 'graficas.html'));
});

// ========== RUTAS PARA LA PAPELERA/HISTORIAL ==========

// Ruta para servir la página de papelera (solo admin)
app.get('/papelera', requireRole('admin'), (req, res) => {
  res.sendFile(path.join(__dirname, 'templates', 'papelera.html'));
});

// Ruta para obtener registros de la papelera con paginación (solo admin)
app.get('/api/papelera', requireRole('admin'), async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const skip = (page - 1) * limit;
    
    // Obtener registros paginados y el total de registros
    const [registros, total] = await Promise.all([
      collections.papelera.find({})
        .sort({ fecha: -1 }) // Ordenar por fecha descendente
        .skip(skip)
        .limit(parseInt(limit))
        .toArray(),
      collections.papelera.countDocuments()
    ]);

    res.json({
      registros,
      total,
      totalPages: Math.ceil(total / limit), // Calcular total de páginas
      currentPage: parseInt(page)
    });
  } catch (err) {
    console.error('Error al obtener registros de papelera:', err);
    res.status(500).json({ error: 'Error al obtener registros' });
  }
});

// Ruta para restaurar un registro eliminado (solo admin)
app.post('/api/papelera/restaurar/:id', requireRole('admin'), async (req, res) => {
  try {
    const { id } = req.params;
    
    // Validar formato del ID
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: 'ID no válido' });
    }

    // Buscar el registro en la papelera
    const registro = await collections.papelera.findOne({ _id: new ObjectId(id) });
    if (!registro) {
      return res.status(404).json({ error: 'Registro no encontrado en papelera' });
    }

    // Solo se pueden restaurar eliminaciones (no inserciones)
    if (registro.tipo === 'eliminacion') {
      // Verificar si ya existe un registro con el mismo ID en la colección destino
      const existe = await collections[registro.coleccion].findOne({ 
        _id: registro.datos._id 
      });
      
      if (existe) {
        return res.status(400).json({ 
          error: 'Ya existe un registro con el mismo ID en la colección destino'
        });
      }

      // Insertar el documento original en la colección
      const result = await collections[registro.coleccion].insertOne(registro.datos);
      
      // Actualizar estado en la papelera para marcar como restaurado
      await collections.papelera.updateOne(
        { _id: new ObjectId(id) },
        { $set: { estado: 'restaurado', fechaRestauracion: new Date() } }
      );

      res.json({ 
        success: true,
        restoredId: result.insertedId,
        collection: registro.coleccion
      });
    } else {
      res.status(400).json({ error: 'Solo se pueden restaurar eliminaciones' });
    }
  } catch (err) {
    console.error('Error al restaurar registro:', err);
    res.status(500).json({ 
      error: 'Error al restaurar registro',
      details: err.message
    });
  }
});

// ========== RUTAS PÚBLICAS ==========

// Ruta principal (página de login)
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'templates', 'login.html'));
});

// Ruta para la página de inicio (requiere autenticación)
app.get('/inicio', (req, res) => {
  if (!req.session.user) {
    return res.redirect('/');
  }
  res.sendFile(path.join(__dirname, 'templates', 'index.html'));
});

// ========== RUTAS FUNCIONALES ==========

// Ruta genérica para obtener datos de cualquier colección
app.get('/:collection', async (req, res, next) => {
  const collection = req.params.collection;
  const validCollections = ['usuario', 'categoria', 'evento', 'rendimientoJugador'];

  // Si la colección no está en la lista de válidas, pasar al siguiente middleware
  if (!validCollections.includes(collection)) {
    return next();
  }

  try {
    if (!collections[collection]) {
      throw new Error(`La colección '${collection}' no está inicializada`);
    }
    
    // Configurar opciones de consulta
    let queryOptions = {};
    
    // Si es la colección 'usuario', excluir el campo 'contrasenia'
    if (collection === 'usuario') {
      queryOptions = {
        projection: {
          contrasenia: 0 // 0 significa excluir este campo
        }
      };
    }
    
    // Obtener todos los documentos de la colección con las opciones aplicadas
    const data = await collections[collection].find({}, queryOptions).toArray();
    
    res.json(data);
  } catch (err) {
    console.error(`❌ Error al obtener ${collection}:`, err.message);
    res.status(500).json({ 
      error: err.message,
      collection: collection
    });
  }
});

// Ruta para obtener jugadores por evento con sus estadísticas
app.get('/jugadoresPorEvento/:idEvento', async (req, res) => {
  try {
    const idEvento = parseInt(req.params.idEvento);

    if (isNaN(idEvento)) {
      return res.status(400).json({ error: 'ID de evento inválido' });
    }

    // Consulta agregada para unir datos de jugadores con sus rendimientos en un evento
    const jugadores = await collections.rendimientoJugador.aggregate([
      { $match: { idEventoFK: idEvento } }, // Filtrar por ID de evento
      {
        $lookup: { // Unir con la colección de usuarios
          from: 'usuario',
          localField: 'idUsuarioFK',
          foreignField: 'idUsuario',
          as: 'jugador'
        }
      },
      { $unwind: '$jugador' }, // Descomponer el array resultante del lookup
      {
        $project: { // Seleccionar y formatear los campos a devolver
          _id: 0,
          idEventoFK: 1,
          asistencia: 1,
          metrosRecorridos: 1,
          pasesRealizados: 1,
          golesRealizados: 1,
          pasesFallidos: 1,
          golesFallidos: 1,
          comentarios: 1,
          jugador: {
            idUsuario: '$jugador.idUsuario',
            nombreUsuario: '$jugador.nombreUsuario',
            tipoUsuario: '$jugador.tipoUsuario',
            telefonoUsuario: '$jugador.telefonoUsuario'
          }
        }
      }
    ]).toArray();

    if (jugadores.length === 0) {
      return res.status(404).json({ 
        message: 'No se encontraron jugadores para este evento',
        idEvento: idEvento
      });
    }

    res.json(jugadores);
  } catch (err) {
    console.error('❌ Error al consultar jugadores por evento:', err.message);
    res.status(500).json({ 
      error: 'Error al consultar jugadores por evento',
      details: err.message
    });
  }
});

// Ruta para validar credenciales de usuario
app.post('/validar', async (req, res) => {
  try {
    const { documento, contrasenia } = req.body;

    if (!documento || !contrasenia) {
      return res.status(400).json({ error: 'Documento y contraseña son requeridos' });
    }

    // Buscar usuario en la base de datos
    const usuario = await collections.usuario.findOne({
      idUsuario: parseInt(documento),
      contrasenia
    });

    if (usuario) {
      res.json({ 
        existe: true, 
        usuario: {
          id: usuario._id,
          idUsuario: usuario.idUsuario,
          nombreUsuario: usuario.nombreUsuario,
          tipoUsuario: usuario.tipoUsuario
        }
      });
    } else {
      res.json({ existe: false });
    }
  } catch (err) {
    console.error('❌ Error al validar usuario:', err.message);
    res.status(500).json({ 
      error: 'Error al validar usuario',
      details: err.message
    });
  }
});

// ========== MANEJO DE ERRORES ==========

// Ruta para manejar páginas no encontradas (404)
app.use((req, res) => {
  res.status(404).send('Página no encontrada');
});

// Manejador de errores global
app.use((err, req, res, next) => {
  console.error('❌ Error global:', err.stack);
  res.status(500).json({
    error: 'Error interno del servidor',
    details: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// ========== INICIO DEL SERVIDOR ==========

// Conectar a la base de datos y luego iniciar el servidor
connectDB().then(() => {
  app.listen(port, () => {
    console.log(`🚀 Servidor escuchando en http://localhost:${port}`);
    console.log(`Modo: ${process.env.NODE_ENV || 'development'}`);
  });
});

// Manejar rechazos de promesas no capturados
process.on('unhandledRejection', (err) => {
  console.error('❌ Unhandled Rejection:', err);
});














