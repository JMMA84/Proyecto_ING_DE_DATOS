/**
 * Bogotá City FC - Sistema de Gestión de Jugadores (MySQL Version)
 * 
 * Este servidor Node.js con Express gestiona la información de jugadores, eventos,
 * categorías y rendimiento de jugadores para el club Bogotá City FC.
 * Utiliza MySQL como base de datos en lugar de MongoDB.
 */

// Importación de módulos requeridos
const express = require('express');
const path = require('path');
const mysql = require('mysql2/promise'); // Cliente MySQL con soporte para promesas
const cors = require('cors');
const session = require('express-session');
const PDFDocument = require('pdfkit');
const blobStream = require('blob-stream');

// Inicialización de la aplicación Express
const app = express();
const port = 3000;

// ========== CONFIGURACIÓN DE MIDDLEWARES ==========
app.use(express.json());
app.use(cors({
  origin: 'http://localhost:' + port,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS']
}));

app.use(session({
  secret: 'secreto_seguro_bogotacity',
  resave: false,
  saveUninitialized: false,
  cookie: { 
    secure: false,
    httpOnly: true,
    sameSite: 'lax'
  }
}));

app.use(express.static(path.join(__dirname, 'public')));

// ========== CONFIGURACIÓN DE BASE DE DATOS ==========
const dbConfig = {
  host: 'localhost',
  user: 'root', // Cambiar por tus credenciales
  password: '', // Cambiar por tu contraseña
  database: 'bogotaCityFC'
};

let pool; // Pool de conexiones MySQL

/**
 * Función para conectar a MySQL y configurar el pool de conexiones
 */
async function connectDB() {
  try {
    pool = mysql.createPool({
      ...dbConfig,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0
    });
    
    console.log('✅ Conectado a MySQL');
    
    // Verificar conexión ejecutando una consulta simple
    const [rows] = await pool.query('SELECT 1 + 1 AS result');
    console.log('Prueba de conexión exitosa:', rows[0].result);
  } catch (err) {
    console.error('❌ Error al conectar a MySQL:', err);
    process.exit(1);
  }
}

// Middleware para verificar conexión a la base de datos
app.use(async (req, res, next) => {
  if (!pool) {
    return res.status(503).json({ error: 'DB no disponible' });
  }
  next();
});

// ========== MIDDLEWARES DE AUTENTICACIÓN Y AUTORIZACIÓN ==========
function requireRole(role) {
  return (req, res, next) => {
    if (!req.session.user) {
      return res.status(401).json({ error: 'No autenticado' });
    }
    if (req.session.user.role !== role) {
      return res.status(403).json({ error: 'Acceso denegado' });
    }
    next();
  };
}

// ========== FUNCIONES PARA GENERAR PDF ==========
async function generatePDF(data, title) {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument();
      const stream = doc.pipe(blobStream());

      doc.fontSize(20).text(title, { align: 'center' });
      doc.moveDown();
      doc.fontSize(10).text(`Generado el: ${new Date().toLocaleString()}`, { align: 'right' });
      doc.moveDown();

      // Verificar si hay datos
      if (data.length === 0) {
        doc.text('No hay datos disponibles');
        doc.end();
        stream.on('finish', () => {
          resolve(stream.toBlob('application/pdf'));
        });
        return;
      }

      const headers = Object.keys(data[0]);
      const rows = data.map(item => Object.values(item));
      const columnWidth = doc.page.width / headers.length;

      // Encabezados de la tabla
      doc.font('Helvetica-Bold');
      headers.forEach((header, i) => {
        doc.text(header, i * columnWidth, doc.y, { width: columnWidth });
      });
      doc.moveDown();

      // Filas de datos
      doc.font('Helvetica');
      rows.forEach(row => {
        row.forEach((cell, i) => {
          const cellText = typeof cell === 'object' ? JSON.stringify(cell) : String(cell);
          doc.text(cellText, i * columnWidth, doc.y, { width: columnWidth });
        });
        doc.moveDown();
      });

      doc.end();

      stream.on('finish', () => {
        resolve(stream.toBlob('application/pdf'));
      });

      stream.on('error', reject);
    } catch (err) {
      reject(err);
    }
  });
}

// ========== RUTAS PARA DESCARGAR PDF ==========
app.get('/download-pdf/:table', requireRole('admin'), async (req, res) => {
  try {
    const { table } = req.params;
    const validTables = ['usuario', 'categoria', 'evento', 'rendimientoJugador'];

    if (!validTables.includes(table)) {
      return res.status(400).json({ error: 'Tabla no válida' });
    }

    const [rows] = await pool.query(`SELECT * FROM ${table}`);
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'No hay datos para generar el PDF' });
    }

    const title = `Reporte de ${table} - Bogotá City FC`;
    const pdfBlob = await generatePDF(rows, title);

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=${table}_report.pdf`);
    res.send(Buffer.from(await pdfBlob.arrayBuffer()));
  } catch (err) {
    console.error('❌ Error al generar PDF:', err);
    res.status(500).json({ error: 'Error al generar PDF', details: err.message });
  }
});

app.get('/download-jugadores-pdf/:idEvento', requireRole('admin'), async (req, res) => {
  try {
    const idEvento = parseInt(req.params.idEvento);

    if (isNaN(idEvento)) {
      return res.status(400).json({ error: 'ID de evento inválido' });
    }

    const [jugadores] = await pool.query(`
      SELECT u.idUsuario, u.nombreUsuario, r.asistencia, r.metrosRecorridos, 
             r.pasesRealizados, r.golesRealizados, r.pasesFallidos, r.golesFallidos, 
             r.comentarios
      FROM rendimientoJugador r
      JOIN usuario u ON r.idUsuarioFK = u.idUsuario
      WHERE r.idEventoFK = ?
    `, [idEvento]);

    if (jugadores.length === 0) {
      return res.status(404).json({ 
        error: 'No hay jugadores para este evento',
        idEvento: idEvento
      });
    }

    // Procesar datos para el PDF
    const flattenedData = jugadores.map(j => ({
      idJugador: j.idUsuario,
      nombre: j.nombreUsuario,
      asistencia: j.asistencia ? 'Sí' : 'No',
      metrosRecorridos: j.metrosRecorridos || '0',
      pasesRealizados: j.pasesRealizados || '0',
      golesRealizados: j.golesRealizados || '0',
      pasesFallidos: j.pasesFallidos || '0',
      golesFallidos: j.golesFallidos || '0',
      comentarios: j.comentarios || 'N/A'
    }));

    const title = `Reporte de Jugadores - Evento ${idEvento}`;
    const pdfBlob = await generatePDF(flattenedData, title);

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=jugadores_evento_${idEvento}.pdf`);
    res.send(Buffer.from(await pdfBlob.arrayBuffer()));
  } catch (err) {
    console.error('❌ Error al generar PDF de jugadores:', err);
    res.status(500).json({ error: 'Error al generar PDF', details: err.message });
  }
});

// ========== FUNCIONES PARA EL HISTORIAL/PAPELERA ==========
async function registrarInsercion(table, documento, usuario) {
  try {
    await pool.query(`
      INSERT INTO actividadBD (registro, fechaActividad)
      VALUES (?, NOW())
    `, [JSON.stringify({
      tipo: 'insercion',
      tabla: table,
      datos: documento,
      usuario: {
        id: usuario.id,
        nombre: usuario.nombreUsuario,
        idUsuario: usuario.idUsuario
      }
    })]);
  } catch (err) {
    console.error('Error registrando inserción:', err);
  }
}

async function registrarEliminacion(table, id, usuario) {
  try {
    let query, params;
    
    if (table === 'usuario') {
      query = 'SELECT * FROM usuario WHERE idUsuario = ?';
      params = [id];
    } else {
      query = `SELECT * FROM ${table} WHERE id = ?`;
      params = [id];
    }
    
    const [documento] = await pool.query(query, params);
    
    if (documento.length > 0) {
      await pool.query(`
        INSERT INTO actividadBD (registro, fechaActividad)
        VALUES (?, NOW())
      `, [JSON.stringify({
        tipo: 'eliminacion',
        tabla: table,
        datos: documento[0],
        usuario: {
          id: usuario.id,
          nombre: usuario.nombreUsuario,
          idUsuario: usuario.idUsuario
        },
        estado: 'eliminado'
      })]);
    }
  } catch (err) {
    console.error('Error registrando eliminación:', err);
  }
}

// Middleware para registrar operaciones POST exitosas
app.use(async (req, res, next) => {
  if (req.method === 'POST' && req.session.user) {
    const originalSend = res.send;
    res.send = async function (body) {
      if (res.statusCode === 201) {
        const urlParts = req.originalUrl.split('/');
        const table = urlParts[urlParts.length - 1];
        if (['usuario', 'categoria', 'evento', 'rendimientoJugador'].includes(table)) {
          try {
            const responseBody = typeof body === 'string' ? JSON.parse(body) : body;
            await registrarInsercion(table, responseBody.usuario || responseBody, req.session.user);
          } catch (err) {
            console.error('Error procesando body para registro:', err);
          }
        }
      }
      originalSend.apply(res, arguments);
    };
  }
  next();
});

// ========== RUTAS DE AUTENTICACIÓN ==========
app.post('/login', async (req, res) => {
  try {
    const { documento, contrasenia } = req.body;

    if (!documento || !contrasenia) {
      return res.status(400).json({ error: 'Documento y contraseña requeridos' });
    }

    const [usuarios] = await pool.query(`
      SELECT * FROM usuario 
      WHERE idUsuario = ? AND contrasenia = ?
    `, [documento, contrasenia]);

    if (usuarios.length === 0) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    const usuario = usuarios[0];
    req.session.user = {
      id: usuario.idUsuario,
      idUsuario: usuario.idUsuario,
      nombreUsuario: usuario.nombreUsuario,
      role: usuario.tipoUsuario === 'admin' ? 'admin' : 'jugador'
    };

    res.json({ success: true, user: req.session.user });
  } catch (err) {
    console.error('❌ Error en login:', err);
    res.status(500).json({ error: 'Error en el servidor' });
  }
});

app.post('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      console.error('Error al cerrar sesión:', err);
      return res.status(500).json({ error: 'Error al cerrar sesión' });
    }
    res.json({ success: true });
  });
});

app.get('/current-user', (req, res) => {
  if (!req.session.user) return res.status(401).json({ error: 'No autenticado' });
  res.json({ user: req.session.user });
});

app.get('/session-data', (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ error: 'No autenticado' });
  }
  res.json(req.session.user);
});

// ========== RUTAS PROTEGIDAS ==========
app.post('/usuario', requireRole('admin'), async (req, res) => {
  try {
    const { nombreUsuario, idUsuario, contrasenia, tipoUsuario, telefonoUsuario, estadoUsuario } = req.body;

    if (!nombreUsuario || !idUsuario || !contrasenia || !tipoUsuario || !telefonoUsuario) {
      return res.status(400).json({ error: 'Todos los campos son obligatorios' });
    }

    const [usuarios] = await pool.query(`
      SELECT * FROM usuario WHERE idUsuario = ?
    `, [idUsuario]);

    if (usuarios.length > 0) {
      return res.status(400).json({ error: 'El ID ya existe' });
    }

    const nuevoUsuario = {
      nombreUsuario,
      idUsuario: parseInt(idUsuario),
      contrasenia,
      tipoUsuario,
      telefonoUsuario,
      estadoUsuario: estadoUsuario === "1" || estadoUsuario === true ? 1 : 0
    };

    await pool.query(`
      INSERT INTO usuario SET ?
    `, [nuevoUsuario]);
    
    res.status(201).json({ 
      success: true, 
      usuario: nuevoUsuario
    });
  } catch (err) {
    console.error('❌ Error al crear usuario:', err);
    res.status(500).json({ error: 'Error al crear usuario', details: err.message });
  }
});
//////////
app.post('/evento', requireRole('admin'), async (req, res) => {
  try {
    const {  idEvento,fechaEvento,tipoEvento,resumenEvento } = req.body;

    if (!idEvento) {
      return res.status(400).json({ error: 'Todos los campos son obligatorios' });
    }

    const [evento] = await pool.query(`
      SELECT * FROM evento WHERE idEvento = ?
    `, [idEvento]);

    if (evento.length > 0) {
      return res.status(400).json({ error: 'El ID ya existe' });
    }

    const nuevoEvento = {
      idEvento: parseInt(idEvento),
      fechaEvento,
      tipoEvento,
      resumenEvento,
    };

    await pool.query(`
      INSERT INTO evento SET ?
    `, [nuevoEvento]);
    
    res.status(201).json({ 
      success: true, 
      evento: nuevoEvento
    });
  } catch (err) {
    console.error('❌ Error al crear evento:', err);
    res.status(500).json({ error: 'Error al crear evento', details: err.message });
  }
});

/////////////////////////////

app.post('/rendimientoJugador', requireRole('admin'), async (req, res) => {
  try {
    const {
      idUsuario, idEvento, asistencia, metrosRecorridos, 
      pasesRealizados, pasesFallidos, golesRealizados, golesFallidos, comentarios 
    } = req.body;

    const nuevoRendimientoJugador = {
      idUsuarioFK: idUsuario,
      idEventoFK: idEvento,
      asistencia: asistencia === "1" || asistencia === true ? 1 : 0,
      metrosRecorridos: parseInt(metrosRecorridos) || 0,
      pasesRealizados: parseInt(pasesRealizados) || 0,
      pasesFallidos: parseInt(pasesFallidos) || 0,
      golesRealizados: parseInt(golesRealizados) || 0,
      golesFallidos: parseInt(golesFallidos) || 0,
      comentarios: comentarios || null
    };

    await pool.query('INSERT INTO rendimientoJugador SET ?', [nuevoRendimientoJugador]);

    res.status(201).json({ 
      success: true, 
      rendimientoJugador: nuevoRendimientoJugador
    });
  } catch (err) {
    console.error('❌ Error al crear rendimiento:', err);
    res.status(500).json({ 
      error: 'Error al crear rendimiento', 
      details: err.message,
      sqlError: err.code
    });
  }
});



///////
app.delete('/:table/:id', requireRole('admin'), async (req, res) => {
  try {
    const { table, id } = req.params;
    
    if (!['usuario', 'categoria', 'evento', 'rendimientoJugador'].includes(table)) {
      return res.status(400).json({ error: 'Tabla no válida' });
    }

    // Registrar la eliminación antes de borrar
    await registrarEliminacion(table, id, req.session.user);

    let result;
    if (table === 'usuario') {
      [result] = await pool.query(`
        DELETE FROM usuario WHERE idUsuario = ?
      `, [id]);
    } else {
      [result] = await pool.query(`
        DELETE FROM ${table} WHERE id = ?
      `, [id]);
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ 
        error: 'Registro no encontrado',
        details: `No se encontró el registro con id: ${id} en la tabla ${table}`
      });
    }

    res.json({ 
      success: true, 
      deletedCount: result.affectedRows,
      deletedId: id
    });
  } catch (err) {
    console.error(`Error al eliminar de ${table}:`, err);
    res.status(500).json({ 
      error: 'Error al eliminar registro',
      details: err.message,
      table: table,
      id: id
    });
  }
});

app.get('/graficas', requireRole('admin'), (req, res) => {
  res.sendFile(path.join(__dirname, 'templates', 'graficas.html'));
});
// Ruta genérica para eliminar cualquier colección
app.delete('/:coleccion/:id', async (req, res) => {
  const { coleccion, id } = req.params;

  try {
    let result;

    if (coleccion === 'usuario') {
      result = await connection.query('DELETE FROM usuario WHERE idUsuario = ?', [id]);
    } else if (coleccion === 'evento') {
      result = await connection.query('DELETE FROM evento WHERE idEvento = ?', [id]);
    } else if (coleccion === 'categoria') {
      result = await connection.query('DELETE FROM categoria WHERE idCategoria = ?', [id]);
    } else if (coleccion === 'rendimientoJugador') {
      result = await connection.query('DELETE FROM rendimientoJugador WHERE idRendimiento = ?', [id]);
    } else {
      return res.status(400).json({ error: 'Colección no válida' });
    }

    res.json({ message: 'Registro eliminado correctamente' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al eliminar' });
  }
});


// ========== RUTAS PARA LA PAPELERA/HISTORIAL ==========
app.get('/papelera', requireRole('admin'), (req, res) => {
  res.sendFile(path.join(__dirname, 'templates', 'papelera.html'));
});

app.get('/api/papelera', requireRole('admin'), async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;
    
    const [registros] = await pool.query(`
      SELECT * FROM actividadBD
      ORDER BY fechaActividad DESC
      LIMIT ? OFFSET ?
    `, [parseInt(limit), offset]);

    const [total] = await pool.query(`
      SELECT COUNT(*) AS total FROM actividadBD
    `);

    res.json({
      registros: registros.map(r => ({
        ...r,
        registro: JSON.parse(r.registro)
      })),
      total: total[0].total,
      totalPages: Math.ceil(total[0].total / limit),
      currentPage: parseInt(page)
    });
  } catch (err) {
    console.error('Error al obtener registros de papelera:', err);
    res.status(500).json({ error: 'Error al obtener registros' });
  }
});

// ========== RUTAS PÚBLICAS ==========
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'templates', 'login.html'));
});

app.get('/inicio', (req, res) => {
  if (!req.session.user) {
    return res.redirect('/');
  }
  res.sendFile(path.join(__dirname, 'templates', 'index.html'));
});

// ========== RUTAS FUNCIONALES ==========
app.get('/:table', async (req, res, next) => {
  const table = req.params.table;
  const validTables = ['usuario', 'categoria', 'evento', 'rendimientoJugador'];

  if (!validTables.includes(table)) {
    return next();
  }

  try {
    const [rows] = await pool.query(`SELECT * FROM ${table}`);
    res.json(rows);
  } catch (err) {
    console.error(`❌ Error al obtener ${table}:`, err.message);
    res.status(500).json({ 
      error: err.message,
      table: table
    });
  }
});

app.get('/jugadoresPorEvento/:idEvento', async (req, res) => {
  try {
    const idEvento = parseInt(req.params.idEvento);

    if (isNaN(idEvento)) {
      return res.status(400).json({ error: 'ID de evento inválido' });
    }

    const [jugadores] = await pool.query(`
      SELECT u.idUsuario, u.nombreUsuario, u.tipoUsuario, u.telefonoUsuario,
             r.idRendimiento, r.asistencia, r.metrosRecorridos, r.pasesRealizados, 
             r.golesRealizados, r.pasesFallidos, r.golesFallidos, r.comentarios
      FROM rendimientoJugador r
      JOIN usuario u ON r.idUsuarioFK = u.idUsuario
      WHERE r.idEventoFK = ?
    `, [idEvento]);

    if (jugadores.length === 0) {
      return res.status(404).json({ 
        message: 'No se encontraron jugadores para este evento',
        idEvento: idEvento
      });
    }

    // Procesar datos de asistencia (convertir Buffer a booleano si es necesario)
    const jugadoresProcesados = jugadores.map(j => {
      if (Buffer.isBuffer(j.asistencia)) {
        j.asistencia = Boolean(j.asistencia[0]);
      }
      return j;
    });

    res.json(jugadoresProcesados);
  } catch (err) {
    console.error('❌ Error al consultar jugadores por evento:', err.message);
    res.status(500).json({ 
      error: 'Error al consultar jugadores por evento',
      details: err.message
    });
  }
});

app.post('/validar', async (req, res) => {
  try {
    const { documento, contrasenia } = req.body;

    if (!documento || !contrasenia) {
      return res.status(400).json({ error: 'Documento y contraseña son requeridos' });
    }

    const [usuarios] = await pool.query(`
      SELECT * FROM usuario 
      WHERE idUsuario = ? AND contrasenia = ?
    `, [documento, contrasenia]);

    if (usuarios.length > 0) {
      const usuario = usuarios[0];
      res.json({ 
        existe: true, 
        usuario: {
          id: usuario.idUsuario,
          idUsuario: usuario.idUsuario,
          nombreUsuario: usuario.nombreUsuario,
          tipoUsuario: usuario.tipoUsuario
        }
      });
    } else {
      res.json({ existe: false });
    }
  } catch (err) {
    console.error('❌ Error al validar usuario:', err.message);
    res.status(500).json({ 
      error: 'Error al validar usuario',
      details: err.message
    });
  }
});

// ========== MANEJO DE ERRORES ==========
app.use((req, res) => {
  res.status(404).send('Página no encontrada');
});

app.use((err, req, res, next) => {
  console.error('❌ Error global:', err.stack);
  res.status(500).json({
    error: 'Error interno del servidor',
    details: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// ========== INICIO DEL SERVIDOR ==========
connectDB().then(() => {
  app.listen(port, () => {
    console.log(`🚀 Servidor escuchando en http://localhost:${port}`);
    console.log(`Modo: ${process.env.NODE_ENV || 'development'}`);
  });
});

process.on('unhandledRejection', (err) => {
  console.error('❌ Unhandled Rejection:', err);
});